
void morse_ip(int pin_led, IPAddress ip_number, int delais) {
  int centaine = ip_number[3] / 100;
  int dizaine = (ip_number[3] - centaine * 100) / 10;
  int unite = ip_number[3] - centaine * 100 - dizaine * 10;

  pinMode(pin_led, OUTPUT);
  digitalWrite(pin_led, HIGH);
  delay(delais * 3);

  if (centaine == 0) {
    for (int i = 0; i < 10; i++) {
      digitalWrite(pin_led, LOW);
      delay(30);
      digitalWrite(pin_led, HIGH);
      delay(30);
    }
  } else {
    for (int i = 0; i < centaine; i++) {
      digitalWrite(pin_led, LOW);
      delay(delais);
      digitalWrite(pin_led, HIGH);
      delay(delais);
    }
  }
  delay(delais * 3);
  if (dizaine == 0) {
    for (int i = 0; i < 10; i++) {
      digitalWrite(pin_led, LOW);
      delay(30);
      digitalWrite(pin_led, HIGH);
      delay(30);
    }
  } else {
    for (int i = 0; i < dizaine; i++) {
      digitalWrite(pin_led, LOW);
      delay(delais);
      digitalWrite(pin_led, HIGH);
      delay(delais);
    }
  }
  delay(delais * 3);
  if (unite == 0) {
    for (int i = 0; i < 10; i++) {
      digitalWrite(pin_led, LOW);
      delay(30);
      digitalWrite(pin_led, HIGH);
      delay(30);
    }
  } else {
    for (int i = 0; i < unite; i++) {
      digitalWrite(pin_led, LOW);
      delay(delais);
      digitalWrite(pin_led, HIGH);
      delay(delais);
    }
  }

}

void wifi_setup() {

  if (debug) {
    Serial.println(" ");
    Serial.println("//////////// Mise en route des connections Wifi /////////////");
    Serial.print("Tentative de connection au point d'acces : ");
    Serial.println(ssid);
    Serial.print("Clef réseau : ");
    Serial.println(pwd);

  }
  int timeout = 0;
  WiFi.mode(WIFI_AP_STA);
  WiFi.begin(ssid, pwd);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    timeout++;
    if (debug) {
      Serial.print(".");
    }
    if (timeout > 20) {
      if (debug) {
        Serial.println("");
        Serial.println(" Délais d'attente de connection dépassé");
        Serial.println("Point d'accès Captobox activé");
        Serial.print("Canal : ");
        Serial.println(canal);
      }

      WiFi.mode(WIFI_AP);
      WiFi.softAP("CaptoBox_AFPD_156282", "", canal.toInt());
      break;
    }
    captobox_ip = WiFi.localIP();
  }
  if (!digitalRead(D3)) {
    Serial.println("Launch Morse IP");
    morse_ip(BUILTIN_LED, captobox_ip, 300);
  }

  if (debug) {
    Serial.println();
    Serial.print("Adresse IP : ");
    Serial.println(captobox_ip);
    Serial.println("#############################################################");
  }
}
