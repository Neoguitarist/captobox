Adafruit_TSL2591 tsl = Adafruit_TSL2591(2591);
H3301 dust_sensor(0x40);
Adafruit_BME680 bme;
Adafruit_CCS811 ccs;

String sensors_labels[] = {"Température", "Humidité", "Pression", "CO2", "COVT", "Luminosité", "PM10", "Test", "Non%20utilisé"}; //liste des capteurs
String sensors[] = {"name_capt1", "name_capt2", "name_capt3", "name_capt4"};
const int nb_of_sensors = 7; //nombre de capteurs

String name_capt[nb_of_sensors];
String value_capt[nb_of_sensors];
String value_min_capt[nb_of_sensors];
String value_max_capt[nb_of_sensors];
String value_unit_capt[nb_of_sensors];
uint16_t lumi;

String getLux(void)
{
  tsl.setGain(TSL2591_GAIN_LOW);
  sensors_event_t event;
  tsl.getEvent(&event);
  if ((event.light == 0) |
      (event.light > 4294966000.0) |
      (event.light < -4294966000.0))
  {
    return "Invalid data";
  }
  else
  {
    return String(event.light);
  }
}

void mesure(int num, int num_capt) {




  switch (num) {
    case 0:
      bme.performReading();
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("mesure de la température : ");
      value_capt[num_capt] = bme.temperature;
      Serial.println(value_capt[num_capt]);
      break;
    case 1:
      bme.performReading();
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("mesure de l'humidité : ");
      value_capt[num_capt] = bme.humidity;
      Serial.println(value_capt[num_capt]);
      break;
    case 2:
      bme.performReading();
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("mesure de la pression : ");
      value_capt[num_capt] = bme.pressure / 100.0;
      Serial.println(value_capt[num_capt]);
      break;
    case 3:
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("mesure du CO2 : ");
      
        if (!ccs.readData()) {
          value_capt[num_capt] = ccs.geteCO2();
          Serial.println(value_capt[num_capt]);
        }
      


      break;
    case 4:
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("mesure du COV : ");
     
        if (!ccs.readData()) {
          value_capt[num_capt] = ccs.getTVOC();
          Serial.println(value_capt[num_capt]);
        }
      

      break;
    case 5:
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("mesure de Luminosité : ");
      value_capt[num_capt] =  getLux();
      Serial.println(value_capt[num_capt]);
      break;
    case 6:
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("Mesure PM10 : ");
      value_capt[num_capt] = dust_sensor.get_atm_PM10_0();
      Serial.println(value_capt[num_capt]);
      break;
    case 7:
      // Capteur de test
      Serial.print("capteur ");
      Serial.println(num_capt);
      Serial.print("capteur test : ");
      value_capt[num_capt] = random(0, 255);

      Serial.println(value_capt[num_capt]);
      break;
  }
}
