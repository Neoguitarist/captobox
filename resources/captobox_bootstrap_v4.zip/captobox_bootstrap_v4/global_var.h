/////////////Configuration de base
String name = "Captobox";
String access_point = "Captobox";
String version = "bootstrap";
boolean debug = true;

////////////////////////Variables Globales
String rate;
String saving = "false";
String ap_mode = "true";
String ssid;
String pwd;
String canal;
String host;
String feed;
String login_name;
String key;
String time_computer;
String latitude;
String longitude;
const long interval = 300;   //intervale de mesure
unsigned long previousMillis = 0; 

const long interval_ada = 10000;   //intervale de mesure
unsigned long previousMillis_ada = 0; 
IPAddress captobox_ip;
