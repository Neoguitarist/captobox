
void read_config() {
  File configuration = LittleFS.open("/config.json", "r");
  const size_t capacity = 6 * JSON_OBJECT_SIZE(5) + JSON_OBJECT_SIZE(11) + 490;
  DynamicJsonDocument doc(capacity);
  String json = configuration.readString();
  int json_len = json.length() + 1;
  char char_json[json_len];

  json.toCharArray(char_json, json_len);

  auto error = deserializeJson(doc, char_json);
  if (error) {
    Serial.print(F("deserializeJson() failed with code "));
    Serial.println(error.c_str());
    return;
  }
  JsonObject sensors = doc["sensors"];

  JsonObject sensors_capt_1 = sensors["capt_1"];
  const char* sensors_capt_1_Name = sensors_capt_1["Name"]; // "Humidité"
  const char* sensors_capt_1_Value = sensors_capt_1["Value"]; // "51.46"
  const char* sensors_capt_1_Min = sensors_capt_1["Min"]; // "0"
  const char* sensors_capt_1_Max = sensors_capt_1["Max"]; // "100"
  const char* sensors_capt_1_Unit = sensors_capt_1["Unit"]; // "%"

  JsonObject sensors_capt_2 = sensors["capt_2"];
  const char* sensors_capt_2_Name = sensors_capt_2["Name"]; // "Température"
  const char* sensors_capt_2_Value = sensors_capt_2["Value"]; // "18.75"
  const char* sensors_capt_2_Min = sensors_capt_2["Min"]; // "0"
  const char* sensors_capt_2_Max = sensors_capt_2["Max"]; // "80"
  const char* sensors_capt_2_Unit = sensors_capt_2["Unit"]; // "°C"

  JsonObject sensors_capt_3 = sensors["capt_3"];
  const char* sensors_capt_3_Name = sensors_capt_3["Name"]; // "Pression"
  const char* sensors_capt_3_Value = sensors_capt_3["Value"]; // "1012.68"
  const char* sensors_capt_3_Min = sensors_capt_3["Min"]; // "1100"
  const char* sensors_capt_3_Max = sensors_capt_3["Max"]; // "900"
  const char* sensors_capt_3_Unit = sensors_capt_3["Unit"]; // "hPa"

  JsonObject sensors_capt_4 = sensors["capt_4"];
  const char* sensors_capt_4_Name = sensors_capt_4["Name"]; // "COV"
  const char* sensors_capt_4_Value = sensors_capt_4["Value"]; // "180"
  const char* sensors_capt_4_Min = sensors_capt_4["Min"]; // "450"
  const char* sensors_capt_4_Max = sensors_capt_4["Max"]; // "2000"
  const char* sensors_capt_4_Unit = sensors_capt_4["Unit"]; // "ppm"

  JsonObject sensors_capt_5 = sensors["capt_5"];
  const char* sensors_capt_5_Name = sensors_capt_5["Name"]; // "name"
  const char* sensors_capt_5_Value = sensors_capt_5["Value"]; // "value"
  const char* sensors_capt_5_Min = sensors_capt_5["Min"]; // "value_min"
  const char* sensors_capt_5_Max = sensors_capt_5["Max"]; // "value_max"
  const char* sensors_capt_5_Unit = sensors_capt_5["Unit"]; // "value_unit"

  const char* Refresh_rate = doc["Refresh_rate"]; // "2000"
  const char* Saving = doc["Saving"]; // ""
  const char* Is_ap = doc["Is_ap"]; // "false"
  const char* Ssid = doc["Ssid"]; // "SFR_06A8"
  const char* Password = doc["Password"]; // "123456789"
  const char* Channel = doc["Channel"]; // "canal"
  const char* Host = doc["Host"]; // ""
  const char* Feed = doc["Feed"]; // "feed"
  const char* Login = doc["Login"]; // "login_name"
  const char* Streaming_Key = doc["Streaming_Key"]; // "key"

  name_capt[0] = String(sensors_capt_1_Name );
  value_capt[0] = String(sensors_capt_1_Value );
  value_min_capt[0] = String(sensors_capt_1_Min);
  value_max_capt[0] = String(sensors_capt_1_Max );
  value_unit_capt[0] = String(sensors_capt_1_Unit );

  name_capt[1] = String(sensors_capt_2_Name );
  value_capt[1] = String(sensors_capt_2_Value );
  value_min_capt[1] = String(sensors_capt_2_Min);
  value_max_capt[1] = String(sensors_capt_2_Max );
  value_unit_capt[1] = String(sensors_capt_2_Unit );

  name_capt[2] = String(sensors_capt_3_Name );
  value_capt[2] = String(sensors_capt_3_Value );
  value_min_capt[2] = String(sensors_capt_3_Min);
  value_max_capt[2] = String(sensors_capt_3_Max );
  value_unit_capt[2] = String(sensors_capt_3_Unit );

  name_capt[3] = String(sensors_capt_4_Name );
  value_capt[3] = String(sensors_capt_4_Value );
  value_min_capt[3] = String(sensors_capt_4_Min);
  value_max_capt[3] = String(sensors_capt_4_Max );
  value_unit_capt[3] = String(sensors_capt_4_Unit );

  name_capt[4] = String(sensors_capt_5_Name );
  value_capt[4] = String(sensors_capt_5_Value );
  value_min_capt[4] = String(sensors_capt_5_Min);
  value_max_capt[4] = String(sensors_capt_5_Max );
  value_unit_capt[4] = String(sensors_capt_5_Unit );

  rate = String( Refresh_rate);
  saving = String(Saving );
  ap_mode = String( Is_ap);
  ssid = String(Ssid );
  pwd = String(Password );
  canal = String( Channel);
  host = String( Host);
  feed = String(Feed);
  login_name = String( Login);
  key = String(Streaming_Key);
  configuration.close();

  if (debug) {
    Serial.println(" ");
    Serial.println("//////////// Configuration de la captobox /////////////");
    Serial.print("Rate : ");
    Serial.println(rate);
    Serial.print("Saving : ");
    Serial.println(saving);
    Serial.print("Ap mode : ");
    Serial.println(ap_mode);
    Serial.print("SSID : ");
    Serial.println(ssid);
    Serial.print("MDP : ");
    Serial.println(pwd);
    Serial.print("Canal : ");
    Serial.println(canal);
    Serial.print("HOST : ");
    Serial.println(host);
    Serial.print("Feed : ");
    Serial.println(feed);
    Serial.print("Login Name : ");
    Serial.println(login_name);
    Serial.print("KEY : ");
    Serial.println(key);
    Serial.println("#######################################################");
    Serial.println(" ");
    Serial.println("//////////// Configuration des capteurs /////////////");
    for (int i = 0; i < 5; i++) {
      Serial.print("Capteur " + String(i) + " : ");
      Serial.println(name_capt[i]);
      Serial.print("MIN : ");
      Serial.println(value_min_capt[i]);
      Serial.print("MAX : ");
      Serial.println(value_max_capt[i]);
      Serial.print("Unité : ");
      Serial.println(value_max_capt[i]);
    }
    Serial.println("#######################################################");
  }
}
void write_config(String json_key[], String json_content[], int size_array) {
  File configuration = LittleFS.open("/config.json", "r+");
  const size_t capacity = 6 * JSON_OBJECT_SIZE(5) + JSON_OBJECT_SIZE(11) + 490;
  DynamicJsonDocument doc(capacity);
  String json = configuration.readString();
  int json_len = json.length() + 1;
  char char_json[json_len];
  json.toCharArray(char_json, json_len);
  auto error = deserializeJson(doc, char_json);
  if (error) {
    Serial.print(F("deserializeJson() failed with code "));
    Serial.println(error.c_str());
    return;
  }
  configuration.close();
  configuration = LittleFS.open("/config.json", "w");

  for (int i = 0; i < size_array - 1; i++) {
    if (json_key[i].indexOf(".") == -1) {
      doc[json_key[i]].set(json_content[i]);
    } else {
      String index = json_key[i].substring(0, json_key[i].indexOf("."));
      String index2 = json_key[i].substring(json_key[i].indexOf(".") + 1, json_key[i].length());
      Serial.println("############################ Deserialzation #########################");
      Serial.print("index : ");
      Serial.println(index);
      Serial.print("index 2 : ");
      Serial.println(index2);
      doc["sensors"][index][index2].set(json_content[i]);
    }
  }
  serializeJson(doc, configuration);
  configuration.close();

  ESP.restart();
}
